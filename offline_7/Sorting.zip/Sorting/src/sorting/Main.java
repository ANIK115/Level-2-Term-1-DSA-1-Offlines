package sorting;

import sorting.mergesort.MergeSort;
import sorting.quicksort.QuickSort;

import java.time.Duration;
import java.time.Instant;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args)  {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        System.out.println("How many numbers?: ");
        int n = scanner.nextInt();
        scanner = new Scanner(System.in);
        System.out.println("Choose an order: 1) Ascending 2) Descending 3) Random: ");
        String order = scanner.nextLine();
        int bound = 100;
        float[] quickSortTimes = new float[10];
        float[] mergeSortTimes = new float[10];
        float totalQuickSortTime = 0.0F;
        float totalMergeSortTime = 0.0F;
        for(int c=0; c<10; c++)
        {
            int[] numbers = new int[n];
            if(order.equalsIgnoreCase("1"))
            {
                numbers[0] = (int) (random.nextFloat()*bound);
                for(int i=1; i<n; i++)
                {
                    numbers[i] = numbers[i-1] + (int) (random.nextFloat()*bound);
                }
            }else if(order.equalsIgnoreCase("2"))
            {
                numbers[0] = (int) (random.nextFloat()*(n+bound));
                for(int i=1; i<n; i++)
                {
                    numbers[i] = numbers[i-1] - (int) (random.nextFloat()*bound);
                }
            }else
            {
                for(int i=0; i<n; i++)
                {
                    numbers[i] = random.nextInt();
                }
            }
            int[] numbers2 = numbers.clone();

            Instant start = Instant.now();
            MergeSort.mergeSort(numbers,0,n-1);
            Instant end = Instant.now();
            Duration timeElapsed = Duration.between(start, end);
            mergeSortTimes[c] = (float) timeElapsed.toMillis();
            totalMergeSortTime+= mergeSortTimes[c];

            for(int x: numbers)
            {
                System.out.print(x+"    ");
            }
            System.out.println();

            Instant start2 = Instant.now();
            QuickSort.quickSort(numbers2,0,n-1);
            Instant end2 = Instant.now();
            Duration timeElapsed2 = Duration.between(start2, end2);
            quickSortTimes[c] = (float) timeElapsed2.toMillis();
            totalQuickSortTime+= quickSortTimes[c];
            for(int x: numbers2)
            {
                System.out.print(x+"    ");
            }
            System.out.println();
            System.out.println("Merge sort time at "+c+"th input= "+mergeSortTimes[c]);
            System.out.println("Quick sort time at "+c+"th input= "+quickSortTimes[c]);
            bound *= 10;
        }
        float avergeTimeForQuickSort = (float) (totalQuickSortTime/10.0);
        float avergeTimeForMergeSort = (float) (totalMergeSortTime/10.0);

        System.out.println("Average time for quick sort: "+avergeTimeForQuickSort);
        System.out.println("Average time for merge sort: "+avergeTimeForMergeSort);
    }
}
